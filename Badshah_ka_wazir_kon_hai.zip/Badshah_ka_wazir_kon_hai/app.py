import streamlit as st
from room import create_room, join_room, get_room, start_game

st.set_page_config(
    page_title="Badshah Ka Wazeer Kon",
    layout="wide" )

st.title(" Badshah Ka Wazeer Kon")
st.markdown("---")

if "room_code" not in st.session_state:
    st.session_state.room_code = ""
if "player_name" not in st.session_state:
    st.session_state.player_name = ""

menu = st.sidebar.radio(
    "Menu",
    [
        "Home",
        "Create Room",
        " Join Room"
    ] )

if menu == " Home":
    st.header("Welcome")
    st.write("""
    ## Traditional Multiplayer Game
    Features
    Create Room
    Join Room
    Four Players
    Random Role Assignment
    Wazeer Guessing
    Live Scoreboard
    """)

elif menu == "➕ Create Room":
    st.header("Create New Room")
    host = st.text_input("Enter Host Name")

    if st.button("Create Room"):
        code = create_room(host)
        st.session_state.room_code = code
        st.session_state.player_name = host
        st.success("Room Created Successfully")
        st.code(code)
        room = get_room(code)
        st.subheader("Connected Players")

        for player in room["players"]:
            st.write("✅", player["name"])

elif menu == "🚪 Join Room":
    st.header("Join Existing Room")
    code = st.text_input("Room Code")
    player = st.text_input("Player Name")

    if st.button("Join"):
        joined = join_room(code, player)
        if joined:
            st.success("Joined Successfully")
            st.session_state.room_code = code
            st.session_state.player_name = player
        else:
            st.error("Invalid Room Code or Room Full")

if st.session_state.room_code != "":
    st.markdown("---")
    room = get_room(st.session_state.room_code)

    st.header("Waiting Room")
    st.write("Room Code")
    st.code(st.session_state.room_code)
    st.subheader("Players")

    for player in room["players"]:
        st.write("👤", player["name"])

    st.info(f"{len(room['players'])} / 4 Players Connected")

    if len(room["players"]) == 4:

        if st.button("🎮 Start Game"):

            start_game(st.session_state.room_code)

            st.success("Game Started Successfully")

            st.rerun()
    else:
        st.warning("Waiting for all 4 players...")