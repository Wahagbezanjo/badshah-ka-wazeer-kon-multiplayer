import json
import os

DATA_FOLDER = "data"
ROOM_FILE = os.path.join(DATA_FOLDER, "rooms.json")


def create_data_folder():

    if not os.path.exists(DATA_FOLDER):
        os.makedirs(DATA_FOLDER)


def create_room_file():

    create_data_folder()

    if not os.path.exists(ROOM_FILE):

        with open(ROOM_FILE, "w") as file:
            json.dump({}, file, indent=4)


def load_rooms():

    create_room_file()

    with open(ROOM_FILE, "r") as file:
        return json.load(file)


def save_rooms(data):

    create_data_folder()

    with open(ROOM_FILE, "w") as file:
        json.dump(data, file, indent=4)


def room_exists(room_code):

    rooms = load_rooms()

    return room_code in rooms


def player_exists(room_code, player_name):

    rooms = load_rooms()

    if room_code not in rooms:
        return False

    for player in rooms[room_code]["players"]:

        if player["name"] == player_name:
            return True

    return False


def total_players(room_code):

    rooms = load_rooms()

    if room_code not in rooms:
        return 0

    return len(rooms[room_code]["players"])


def get_players(room_code):

    rooms = load_rooms()

    if room_code not in rooms:
        return []

    return rooms[room_code]["players"]


def update_players(room_code, players):

    rooms = load_rooms()

    if room_code not in rooms:
        return

    rooms[room_code]["players"] = players

    save_rooms(rooms)


def remove_room(room_code):

    rooms = load_rooms()

    if room_code in rooms:

        del rooms[room_code]

        save_rooms(rooms)


def reset_database():

    save_rooms({})


def get_room_state(room_code):

    rooms = load_rooms()

    if room_code not in rooms:
        return None

    return rooms[room_code]["state"]


def update_room_state(room_code, state):

    rooms = load_rooms()

    if room_code not in rooms:
        return

    rooms[room_code]["state"] = state

    save_rooms(rooms)


def get_round(room_code):

    rooms = load_rooms()

    if room_code not in rooms:
        return 0

    return rooms[room_code]["round"]


def update_round(room_code, round_number):

    rooms = load_rooms()

    if room_code not in rooms:
        return

    rooms[room_code]["round"] = round_number

    save_rooms(rooms)