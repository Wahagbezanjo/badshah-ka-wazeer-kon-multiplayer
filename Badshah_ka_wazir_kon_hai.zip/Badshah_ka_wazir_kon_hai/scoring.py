def calculate_scores(players, guess_correct):

    if guess_correct:

        points = {
            "Badshah": 100,
            "Wazeer": 80,
            "Sipahi": 50,
            "Chor": 0
        }

    else:

        points = {
            "Badshah": 100,
            "Wazeer": -20,
            "Sipahi": 50,
            "Chor": 120
        }

    for player in players:
        player["score"] += points[player["role"]]

    return players


def get_scoreboard(players):

    return sorted(
        players,
        key=lambda x: x["score"],
        reverse=True
    )


def get_winner(players):

    board = get_scoreboard(players)

    return board[0]


def get_rankings(players):

    board = get_scoreboard(players)

    rankings = []

    rank = 1

    for player in board:

        rankings.append({
            "rank": rank,
            "name": player["name"],
            "score": player["score"],
            "role": player.get("role", "")
        })

        rank += 1

    return rankings


def display_scores(players):

    board = get_scoreboard(players)

    for player in board:

        print(
            player["name"],
            "-",
            player["score"]
        )


def reset_scores(players):

    for player in players:

        player["score"] = 0

    return players


def highest_score(players):

    board = get_scoreboard(players)

    return board[0]["score"]


def lowest_score(players):

    board = get_scoreboard(players)

    return board[-1]["score"]


def total_points(players):

    total = 0

    for player in players:

        total += player["score"]

    return total


def player_exists(players, name):

    for player in players:

        if player["name"] == name:
            return True

    return False


def get_player_score(players, name):

    for player in players:

        if player["name"] == name:
            return player["score"]

    return None


def add_bonus(players, name, bonus):

    for player in players:

        if player["name"] == name:
            player["score"] += bonus

    return players


def deduct_points(players, name, points):

    for player in players:

        if player["name"] == name:
            player["score"] -= points

    return players