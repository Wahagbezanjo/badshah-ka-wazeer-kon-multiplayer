import random

roles = ["Badshah", "Wazeer", "Sipahi", "Chor"]


def assign_roles(players):
    shuffled_roles = roles.copy()
    random.shuffle(shuffled_roles)

    for i in range(len(players)):
        players[i]["role"] = shuffled_roles[i]

    return players


def get_player_role(players, player_name):
    for player in players:
        if player["name"] == player_name:
            return player["role"]

    return None


def reveal_roles(players):
    data = []

    for player in players:
        data.append(
            {
                "name": player["name"],
                "role": player["role"]
            }
        )

    return data


def get_badshah(players):
    for player in players:
        if player["role"] == "Badshah":
            return player

    return None


def get_wazeer(players):
    for player in players:
        if player["role"] == "Wazeer":
            return player

    return None


def get_sipahi(players):
    for player in players:
        if player["role"] == "Sipahi":
            return player

    return None


def get_chor(players):
    for player in players:
        if player["role"] == "Chor":
            return player

    return None


def reveal_for_players(players):
    visible = []

    for player in players:

        if player["role"] == "Badshah":
            visible.append(
                {
                    "name": player["name"],
                    "role": "Badshah"
                }
            )

        elif player["role"] == "Wazeer":
            visible.append(
                {
                    "name": player["name"],
                    "role": "Wazeer"
                }
            )

        else:
            visible.append(
                {
                    "name": player["name"],
                    "role": "Hidden"
                }
            )

    return visible


def get_hidden_players(players):
    hidden = []

    for player in players:

        if player["role"] in ["Sipahi", "Chor"]:
            hidden.append(player["name"])

    return hidden


def check_guess(players, guessed_name):

    chor = get_chor(players)

    if chor["name"] == guessed_name:
        return True

    return False


def game_result(players, guessed_name):

    result = {}

    result["correct"] = check_guess(players, guessed_name)

    result["roles"] = reveal_roles(players)

    return result


def reset_roles(players):

    for player in players:

        if "role" in player:
            del player["role"]

    return players


def game_finished(room):

    if room["round"] > room["max_rounds"]:
        return True

    return False