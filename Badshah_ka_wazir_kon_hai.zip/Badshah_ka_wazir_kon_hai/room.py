import random
import string

from utils import load_rooms, save_rooms
from game import assign_roles


def generate_room_code():
    while True:
        code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
        rooms = load_rooms()
        if code not in rooms:
            return code


def create_room(host_name):
    rooms = load_rooms()

    code = generate_room_code()

    rooms[code] = {
        "players": [
            {
                "name": host_name,
                "score": 0
            }
        ],
        "round": 1,
        "max_rounds": 5,
        "state": "waiting"
    }

    save_rooms(rooms)

    return code


def join_room(code, player_name):
    rooms = load_rooms()

    if code not in rooms:
        return False

    room = rooms[code]

    if room["state"] != "waiting":
        return False

    if len(room["players"]) >= 4:
        return False

    for player in room["players"]:
        if player["name"] == player_name:
            return False

    room["players"].append(
        {
            "name": player_name,
            "score": 0
        }
    )

    save_rooms(rooms)

    return True


def get_room(code):
    rooms = load_rooms()
    return rooms.get(code)


def update_room(code, room):
    rooms = load_rooms()
    rooms[code] = room
    save_rooms(rooms)


def start_game(code):
    rooms = load_rooms()

    if code not in rooms:
        return False

    room = rooms[code]

    if len(room["players"]) != 4:
        return False

    assign_roles(room["players"])

    room["state"] = "playing"

    rooms[code] = room

    save_rooms(rooms)

    return True


def next_round(code):
    rooms = load_rooms()

    if code not in rooms:
        return False

    room = rooms[code]

    room["round"] += 1

    if room["round"] > room["max_rounds"]:
        room["state"] = "finished"
    else:
        assign_roles(room["players"])
        room["state"] = "playing"

    rooms[code] = room

    save_rooms(rooms)

    return True


def reset_room(code):
    rooms = load_rooms()

    if code not in rooms:
        return False

    room = rooms[code]

    room["round"] = 1
    room["state"] = "waiting"

    for player in room["players"]:
        player["score"] = 0
        if "role" in player:
            del player["role"]

    rooms[code] = room

    save_rooms(rooms)

    return True


def delete_room(code):
    rooms = load_rooms()

    if code in rooms:
        del rooms[code]
        save_rooms(rooms)
        return True

    return False